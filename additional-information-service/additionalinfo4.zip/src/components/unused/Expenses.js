import React from 'react';
import Template from '../Template.js';

const Wrapper = () => <div />;

const Expenses = Template(Wrapper, 'Expenses');

export default Expenses;
