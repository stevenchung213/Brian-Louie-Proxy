import React from 'react';
import Template from '../Template.js';

const Wrapper = () => <div />;

const Schools = Template(Wrapper, 'Schools');

export default Schools;
